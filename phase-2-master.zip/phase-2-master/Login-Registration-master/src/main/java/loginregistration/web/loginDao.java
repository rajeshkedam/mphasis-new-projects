package loginregistration.web;

public enum loginDao {
	;

	boolean validate(loginBean loginBean) {
		// TODO Auto-generated method stub
		return false;
	}

}
