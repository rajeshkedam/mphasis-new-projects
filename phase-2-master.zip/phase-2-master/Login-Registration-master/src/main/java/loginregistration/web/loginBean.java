package loginregistration.web;

public enum loginBean {
	;

	void setPassword(String password) {
		// TODO Auto-generated method stub
		
	}

	void setUsername(String username) {
		// TODO Auto-generated method stub
		
	}

}
