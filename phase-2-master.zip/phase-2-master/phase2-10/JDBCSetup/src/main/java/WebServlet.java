
public @interface WebServlet {

}
