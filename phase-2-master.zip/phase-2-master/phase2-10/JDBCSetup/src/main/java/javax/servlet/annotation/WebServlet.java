package javax.servlet.annotation;

public class WebServlet {

}
