package com.ecommerce;

public class EProductParts {

}
