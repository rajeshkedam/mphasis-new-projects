# Simple JSF+Hibernate+Spring Integration Project

  	This project is very easy to understand JSF,Spring and Hibernate integration.
  	
Project Structure

 ![Alt text](http://i.hizliresim.com/ZLYddV.png "Project Structure")

If you want to use this project.You need little change.

		1.Go to WEB-INF/applicationContext.xml.
		Fill empty fields at dataSource bean like username and password.
		
		2.Go to main/resources/hibernate.cfg.xml.
		Fill empty fields like username and password.
		(It is necessary for hibernate auto code generation.)
		
		3.Go to main/resources/database.sql.
		Execute sql code in your Mysql database.

That's all!

Finally, You can run the project.

Have Fun!
