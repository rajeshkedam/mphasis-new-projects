package seleniumscriptsday4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNGDemo {
	@Test
	public void login()
	{
		System.out.println("loginto the application");
		
	}
	@Test
	public void ComposeEmail()
	{
		System.out.println("Compose an email");
	}
	@Test
	public void SendEmail()
	{
		System.out.println("Send an email");
	}
	
}
